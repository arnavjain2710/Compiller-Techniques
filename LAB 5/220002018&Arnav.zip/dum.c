scanf("hello");
printf("hello");
printf("hello\n");
scanf("hello");
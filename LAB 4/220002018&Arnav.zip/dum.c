//hellow world
/*hello world1*/
/*hello world2
*/
/*hello world3
hello world3.1*/
#include<stdio.h>
